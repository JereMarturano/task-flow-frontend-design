import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { avatarColor, initials } from "@/lib/data"
import { cn } from "@/lib/utils"

export function UserCell({
  name,
  className,
  hideName,
}: {
  name: string
  className?: string
  hideName?: boolean
}) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <Avatar className="size-6">
        <AvatarFallback className={cn("text-[10px]", avatarColor(name))}>
          {initials(name)}
        </AvatarFallback>
      </Avatar>
      {!hideName && <span className="truncate text-sm">{name}</span>}
    </div>
  )
}
