"use client"

import {
  LayoutDashboard,
  ListChecks,
  KanbanSquare,
  Users,
  BarChart3,
  Settings,
  Plus,
} from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuBadge,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { TaskFlowLogo } from "@/components/taskflow-logo"
import { useTasks } from "@/components/task-store"

export type View =
  | "dashboard"
  | "tasks"
  | "kanban"
  | "team"
  | "reports"
  | "settings"

const nav: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "tasks", label: "Tasks", icon: ListChecks },
  { id: "kanban", label: "Kanban", icon: KanbanSquare },
  { id: "team", label: "Team", icon: Users },
  { id: "reports", label: "Reports", icon: BarChart3 },
  { id: "settings", label: "Settings", icon: Settings },
]

export function AppSidebar({
  view,
  onChange,
  onCreate,
}: {
  view: View
  onChange: (v: View) => void
  onCreate: () => void
}) {
  const { tasks } = useTasks()
  const openCount = tasks.filter((t) => t.status !== "Done").length

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border">
        <div className="flex items-center gap-2.5 px-1 py-1.5">
          <TaskFlowLogo className="size-8 shrink-0" />
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-semibold tracking-tight">
              TaskFlow
            </span>
            <span className="text-xs text-muted-foreground">NovaTech</span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent className="px-1 pt-1">
            <Button className="w-full justify-start gap-2" onClick={onCreate}>
              <Plus className="size-4" />
              New task
            </Button>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Workspace</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {nav.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton
                    isActive={view === item.id}
                    onClick={() => onChange(item.id)}
                    tooltip={item.label}
                  >
                    <item.icon />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                  {item.id === "tasks" && openCount > 0 && (
                    <SidebarMenuBadge>{openCount}</SidebarMenuBadge>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        <div className="flex items-center gap-2 rounded-md px-2 py-2 text-xs text-muted-foreground">
          <span className="size-2 rounded-full bg-emerald-500" />
          All systems operational
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
