"use client"

import {
  createContext,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react"
import {
  tasks as seedTasks,
  type Task,
  type TaskStatus,
  type Priority,
} from "@/lib/data"

interface NewTaskInput {
  title: string
  description?: string
  responsible: string
  status: TaskStatus
  priority: Priority
}

interface TaskStore {
  tasks: Task[]
  addTask: (input: NewTaskInput) => void
  updateStatus: (id: string, status: TaskStatus) => void
  getTask: (id: string) => Task | undefined
}

const TaskContext = createContext<TaskStore | null>(null)

let counter = 200

export function TaskProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>(seedTasks)

  const value = useMemo<TaskStore>(() => {
    return {
      tasks,
      addTask: (input) => {
        const now = new Date().toISOString()
        counter += 1
        const newTask: Task = {
          id: String(counter),
          key: `NOVA-${counter}`,
          title: input.title,
          description: input.description,
          responsible: input.responsible,
          status: input.status,
          priority: input.priority,
          tags: [],
          createdAt: now,
          updatedAt: now,
          activity: [
            {
              id: "a1",
              type: "created",
              actor: input.responsible,
              message: "created this task",
              timestamp: now,
            },
          ],
        }
        setTasks((prev) => [newTask, ...prev])
      },
      updateStatus: (id, status) => {
        setTasks((prev) =>
          prev.map((t) => {
            if (t.id !== id || t.status === status) return t
            const now = new Date().toISOString()
            return {
              ...t,
              status,
              updatedAt: now,
              activity: [
                ...t.activity,
                {
                  id: `a${t.activity.length + 1}`,
                  type: "status",
                  actor: t.responsible,
                  message: `moved to ${status === "InProgress" ? "In Progress" : status}`,
                  timestamp: now,
                },
              ],
            }
          }),
        )
      },
      getTask: (id) => tasks.find((t) => t.id === id),
    }
  }, [tasks])

  return <TaskContext.Provider value={value}>{children}</TaskContext.Provider>
}

export function useTasks() {
  const ctx = useContext(TaskContext)
  if (!ctx) throw new Error("useTasks must be used within TaskProvider")
  return ctx
}
