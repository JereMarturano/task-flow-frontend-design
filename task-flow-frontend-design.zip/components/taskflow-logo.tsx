export function TaskFlowLogo({ className }: { className?: string }) {
  return (
    <div className={className} aria-hidden="true">
      <svg
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="size-full"
      >
        <rect width="32" height="32" rx="8" className="fill-primary" />
        <path
          d="M9 11.5C9 10.6716 9.67157 10 10.5 10H21.5C22.3284 10 23 10.6716 23 11.5C23 12.3284 22.3284 13 21.5 13H10.5C9.67157 13 9 12.3284 9 11.5Z"
          className="fill-primary-foreground"
        />
        <path
          d="M9 16.5C9 15.6716 9.67157 15 10.5 15H17.5C18.3284 15 19 15.6716 19 16.5C19 17.3284 18.3284 18 17.5 18H10.5C9.67157 18 9 17.3284 9 16.5Z"
          className="fill-primary-foreground/70"
        />
        <path
          d="M9 21.5C9 20.6716 9.67157 20 10.5 20H14.5C15.3284 20 16 20.6716 16 21.5C16 22.3284 15.3284 23 14.5 23H10.5C9.67157 23 9 22.3284 9 21.5Z"
          className="fill-primary-foreground/40"
        />
      </svg>
    </div>
  )
}
