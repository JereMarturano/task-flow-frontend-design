"use client"

import { Bell, Search, Check } from "lucide-react"
import { useState } from "react"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { avatarColor, initials } from "@/lib/data"

const notifications = [
  {
    id: "n1",
    title: "Lena Park commented on NOVA-101",
    time: "12m ago",
    unread: true,
  },
  {
    id: "n2",
    title: "NOVA-104 was moved to Done",
    time: "1h ago",
    unread: true,
  },
  {
    id: "n3",
    title: "Diego Ramos was assigned NOVA-108",
    time: "3h ago",
    unread: false,
  },
]

export function AppHeader({ title }: { title: string }) {
  const [query, setQuery] = useState("")
  const unread = notifications.filter((n) => n.unread).length

  return (
    <header className="sticky top-0 z-30 flex h-16 shrink-0 items-center gap-3 border-b border-border bg-background/80 px-4 backdrop-blur-md md:px-6">
      <SidebarTrigger className="-ml-1" />
      <Separator orientation="vertical" className="mr-1 h-6 max-md:hidden" />

      <h1 className="text-base font-semibold tracking-tight max-md:hidden">
        {title}
      </h1>

      <div className="relative ml-auto w-full max-w-md max-sm:max-w-[180px]">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search tasks, people..."
          className="h-9 pl-9 pr-12"
          aria-label="Global search"
        />
        <kbd className="pointer-events-none absolute right-2.5 top-1/2 hidden -translate-y-1/2 items-center gap-0.5 rounded border border-border bg-muted px-1.5 font-mono text-[10px] text-muted-foreground sm:flex">
          ⌘K
        </kbd>
      </div>

      <ThemeToggle />

      <Popover>
        <PopoverTrigger
          render={
            <Button
              variant="ghost"
              size="icon"
              aria-label="Notifications"
              className="relative"
            />
          }
        >
          <Bell className="size-[18px]" />
          {unread > 0 && (
            <span className="absolute right-1.5 top-1.5 flex size-2 rounded-full bg-primary ring-2 ring-background" />
          )}
        </PopoverTrigger>
        <PopoverContent align="end" className="w-80 p-0">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <span className="text-sm font-semibold">Notifications</span>
            <Badge variant="secondary">{unread} new</Badge>
          </div>
          <div className="flex flex-col">
            {notifications.map((n) => (
              <div
                key={n.id}
                className="flex items-start gap-3 border-b border-border px-4 py-3 last:border-0 hover:bg-accent/50"
              >
                <span
                  className={`mt-1.5 size-2 shrink-0 rounded-full ${
                    n.unread ? "bg-primary" : "bg-transparent"
                  }`}
                />
                <div className="flex flex-col gap-0.5">
                  <span className="text-sm leading-snug">{n.title}</span>
                  <span className="text-xs text-muted-foreground">
                    {n.time}
                  </span>
                </div>
              </div>
            ))}
          </div>
          <div className="p-2">
            <Button variant="ghost" size="sm" className="w-full gap-2">
              <Check className="size-4" />
              Mark all as read
            </Button>
          </div>
        </PopoverContent>
      </Popover>

      <DropdownMenu>
        <DropdownMenuTrigger
          render={
            <Button
              variant="ghost"
              className="h-9 gap-2 px-1.5 pr-2.5 max-sm:px-1"
              aria-label="Account menu"
            />
          }
        >
          <Avatar className="size-7">
            <AvatarFallback className={avatarColor("Ana Torres")}>
              {initials("Ana Torres")}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm font-medium max-sm:hidden">Ana Torres</span>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel>
            <div className="flex flex-col">
              <span className="text-sm font-medium">Ana Torres</span>
              <span className="text-xs font-normal text-muted-foreground">
                ana.torres@novatech.io
              </span>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuGroup>
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>Workspace settings</DropdownMenuItem>
            <DropdownMenuItem>Billing</DropdownMenuItem>
          </DropdownMenuGroup>
          <DropdownMenuSeparator />
          <DropdownMenuItem variant="destructive">Sign out</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  )
}
