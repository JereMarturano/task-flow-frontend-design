"use client"

import { Mail } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { useTasks } from "@/components/task-store"
import { members, avatarColor, initials } from "@/lib/data"

export function TeamView() {
  const { tasks } = useTasks()

  return (
    <div className="flex flex-col gap-4 p-4 md:p-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {members.map((member) => {
          const assigned = tasks.filter((t) => t.responsible === member.name)
          const done = assigned.filter((t) => t.status === "Done").length
          const active = assigned.filter(
            (t) => t.status === "InProgress",
          ).length
          const completion = assigned.length
            ? Math.round((done / assigned.length) * 100)
            : 0
          return (
            <Card key={member.id}>
              <CardContent className="flex flex-col gap-4 p-5">
                <div className="flex items-center gap-3">
                  <Avatar className="size-11">
                    <AvatarFallback
                      className={`text-sm font-medium ${avatarColor(member.name)}`}
                    >
                      {initials(member.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium text-foreground">
                      {member.name}
                    </p>
                    <p className="truncate text-sm text-muted-foreground">
                      {member.role}
                    </p>
                  </div>
                  <Badge variant="secondary">{assigned.length} tasks</Badge>
                </div>

                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="size-4" aria-hidden />
                  <span className="truncate">{member.email}</span>
                </div>

                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Completion</span>
                    <span className="font-medium text-foreground">
                      {completion}%
                    </span>
                  </div>
                  <Progress value={completion} />
                </div>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <Stat label="Active" value={active} />
                  <Stat label="Done" value={done} />
                  <Stat label="Total" value={assigned.length} />
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg border bg-muted/40 py-2">
      <p className="text-lg font-semibold text-foreground">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  )
}
