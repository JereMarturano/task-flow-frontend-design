"use client"

import { useMemo, useState } from "react"
import {
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Filter,
  Plus,
  Search,
  X,
} from "lucide-react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty"
import { StatusBadge } from "@/components/status-badge"
import { UserCell } from "@/components/user-cell"
import { useTasks } from "@/components/task-store"
import {
  priorityMeta,
  formatRelative,
  type Priority,
  type TaskStatus,
  type Task,
} from "@/lib/data"
import { useSimulatedLoading } from "@/hooks/use-simulated-loading"
import { cn } from "@/lib/utils"

type SortKey = "key" | "title" | "status" | "priority" | "updatedAt"
type SortDir = "asc" | "desc"

const priorityOrder: Record<Priority, number> = {
  Low: 0,
  Medium: 1,
  High: 2,
  Urgent: 3,
}
const statusOrder: Record<TaskStatus, number> = {
  ToDo: 0,
  InProgress: 1,
  Done: 2,
}

const PAGE_SIZE = 8

export function TasksView({
  onOpenTask,
  onCreate,
}: {
  onOpenTask: (id: string) => void
  onCreate: () => void
}) {
  const { tasks } = useTasks()
  const loading = useSimulatedLoading(500)

  const [query, setQuery] = useState("")
  const [status, setStatus] = useState<TaskStatus | "all">("all")
  const [priority, setPriority] = useState<Priority | "all">("all")
  const [sortKey, setSortKey] = useState<SortKey>("updatedAt")
  const [sortDir, setSortDir] = useState<SortDir>("desc")
  const [page, setPage] = useState(1)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    const result = tasks.filter((t) => {
      const matchesQuery =
        !q ||
        t.title.toLowerCase().includes(q) ||
        t.key.toLowerCase().includes(q) ||
        t.responsible.toLowerCase().includes(q)
      const matchesStatus = status === "all" || t.status === status
      const matchesPriority = priority === "all" || t.priority === priority
      return matchesQuery && matchesStatus && matchesPriority
    })

    result.sort((a, b) => {
      let cmp = 0
      switch (sortKey) {
        case "key":
          cmp = a.key.localeCompare(b.key)
          break
        case "title":
          cmp = a.title.localeCompare(b.title)
          break
        case "status":
          cmp = statusOrder[a.status] - statusOrder[b.status]
          break
        case "priority":
          cmp = priorityOrder[a.priority] - priorityOrder[b.priority]
          break
        case "updatedAt":
          cmp = new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime()
          break
      }
      return sortDir === "asc" ? cmp : -cmp
    })
    return result
  }, [tasks, query, status, priority, sortKey, sortDir])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const currentPage = Math.min(page, totalPages)
  const paged = filtered.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE,
  )

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"))
    } else {
      setSortKey(key)
      setSortDir("asc")
    }
    setPage(1)
  }

  const hasFilters = query !== "" || status !== "all" || priority !== "all"
  const clearFilters = () => {
    setQuery("")
    setStatus("all")
    setPriority("all")
    setPage(1)
  }

  return (
    <div className="flex flex-col gap-4 p-4 md:p-6">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="relative w-full lg:max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              setPage(1)
            }}
            placeholder="Search by title, key, or assignee"
            className="pl-9"
            aria-label="Search tasks"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Filter className="size-4 text-muted-foreground" aria-hidden />
          <Select
            value={status}
            onValueChange={(v) => {
              setStatus(v as TaskStatus | "all")
              setPage(1)
            }}
          >
            <SelectTrigger size="sm" className="w-36" aria-label="Filter by status">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="ToDo">To Do</SelectItem>
              <SelectItem value="InProgress">In Progress</SelectItem>
              <SelectItem value="Done">Done</SelectItem>
            </SelectContent>
          </Select>
          <Select
            value={priority}
            onValueChange={(v) => {
              setPriority(v as Priority | "all")
              setPage(1)
            }}
          >
            <SelectTrigger size="sm" className="w-36" aria-label="Filter by priority">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All priorities</SelectItem>
              <SelectItem value="Urgent">Urgent</SelectItem>
              <SelectItem value="High">High</SelectItem>
              <SelectItem value="Medium">Medium</SelectItem>
              <SelectItem value="Low">Low</SelectItem>
            </SelectContent>
          </Select>
          {hasFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters}>
              <X data-icon="inline-start" />
              Clear
            </Button>
          )}
          <Button size="sm" onClick={onCreate}>
            <Plus data-icon="inline-start" />
            New Task
          </Button>
        </div>
      </div>

      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <SortableHead
                label="Key"
                active={sortKey === "key"}
                dir={sortDir}
                onClick={() => toggleSort("key")}
                className="w-28"
              />
              <SortableHead
                label="Title"
                active={sortKey === "title"}
                dir={sortDir}
                onClick={() => toggleSort("title")}
              />
              <TableHead className="hidden md:table-cell">Assignee</TableHead>
              <SortableHead
                label="Status"
                active={sortKey === "status"}
                dir={sortDir}
                onClick={() => toggleSort("status")}
                className="w-36"
              />
              <SortableHead
                label="Priority"
                active={sortKey === "priority"}
                dir={sortDir}
                onClick={() => toggleSort("priority")}
                className="hidden w-28 sm:table-cell"
              />
              <SortableHead
                label="Updated"
                active={sortKey === "updatedAt"}
                dir={sortDir}
                onClick={() => toggleSort("updatedAt")}
                className="hidden w-32 lg:table-cell"
              />
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              Array.from({ length: 6 }).map((_, i) => <RowSkeleton key={i} />)
            ) : paged.length === 0 ? (
              <TableRow className="hover:bg-transparent">
                <TableCell colSpan={6} className="py-0">
                  <Empty className="border-0">
                    <EmptyHeader>
                      <EmptyMedia variant="icon">
                        <Search />
                      </EmptyMedia>
                      <EmptyTitle>No tasks found</EmptyTitle>
                      <EmptyDescription>
                        Try adjusting your search or filters to find what you
                        are looking for.
                      </EmptyDescription>
                    </EmptyHeader>
                    <EmptyContent>
                      <Button variant="outline" size="sm" onClick={clearFilters}>
                        Clear filters
                      </Button>
                    </EmptyContent>
                  </Empty>
                </TableCell>
              </TableRow>
            ) : (
              paged.map((task) => (
                <TaskRow key={task.id} task={task} onOpen={onOpenTask} />
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {!loading && filtered.length > 0 && (
        <div className="flex flex-col items-center justify-between gap-3 sm:flex-row">
          <p className="text-sm text-muted-foreground">
            Showing{" "}
            <span className="font-medium text-foreground">
              {(currentPage - 1) * PAGE_SIZE + 1}
            </span>
            {"–"}
            <span className="font-medium text-foreground">
              {Math.min(currentPage * PAGE_SIZE, filtered.length)}
            </span>{" "}
            of{" "}
            <span className="font-medium text-foreground">
              {filtered.length}
            </span>{" "}
            tasks
          </p>
          <nav className="flex items-center gap-1" aria-label="Pagination">
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
            >
              Previous
            </Button>
            {Array.from({ length: totalPages }).map((_, i) => (
              <Button
                key={i}
                variant={currentPage === i + 1 ? "default" : "outline"}
                size="icon-sm"
                className="hidden sm:inline-flex"
                onClick={() => setPage(i + 1)}
                aria-current={currentPage === i + 1 ? "page" : undefined}
              >
                {i + 1}
              </Button>
            ))}
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            >
              Next
            </Button>
          </nav>
        </div>
      )}
    </div>
  )
}

function SortableHead({
  label,
  active,
  dir,
  onClick,
  className,
}: {
  label: string
  active: boolean
  dir: SortDir
  onClick: () => void
  className?: string
}) {
  return (
    <TableHead className={className}>
      <button
        type="button"
        onClick={onClick}
        className={cn(
          "-ml-1 inline-flex items-center gap-1 rounded px-1 py-0.5 text-xs font-medium uppercase tracking-wide transition-colors hover:text-foreground",
          active ? "text-foreground" : "text-muted-foreground",
        )}
      >
        {label}
        {active ? (
          dir === "asc" ? (
            <ArrowUp className="size-3" />
          ) : (
            <ArrowDown className="size-3" />
          )
        ) : (
          <ArrowUpDown className="size-3 opacity-50" />
        )}
      </button>
    </TableHead>
  )
}

function TaskRow({
  task,
  onOpen,
}: {
  task: Task
  onOpen: (id: string) => void
}) {
  return (
    <TableRow
      className="cursor-pointer"
      onClick={() => onOpen(task.id)}
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter") onOpen(task.id)
      }}
    >
      <TableCell className="font-mono text-xs text-muted-foreground">
        {task.key}
      </TableCell>
      <TableCell>
        <div className="flex flex-col gap-1">
          <span className="font-medium leading-tight text-foreground">
            {task.title}
          </span>
          {task.tags.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {task.tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="font-normal">
                  {tag}
                </Badge>
              ))}
            </div>
          )}
        </div>
      </TableCell>
      <TableCell className="hidden md:table-cell">
        <UserCell name={task.responsible} />
      </TableCell>
      <TableCell>
        <StatusBadge status={task.status} />
      </TableCell>
      <TableCell className="hidden sm:table-cell">
        <span
          className={cn(
            "inline-flex items-center gap-1.5 text-sm font-medium",
            priorityMeta[task.priority].className,
          )}
        >
          <span className="size-1.5 rounded-full bg-current" aria-hidden />
          {priorityMeta[task.priority].label}
        </span>
      </TableCell>
      <TableCell className="hidden text-sm text-muted-foreground lg:table-cell">
        {formatRelative(task.updatedAt)}
      </TableCell>
    </TableRow>
  )
}

function RowSkeleton() {
  return (
    <TableRow className="hover:bg-transparent">
      <TableCell>
        <Skeleton className="h-4 w-16" />
      </TableCell>
      <TableCell>
        <Skeleton className="h-4 w-64" />
      </TableCell>
      <TableCell className="hidden md:table-cell">
        <div className="flex items-center gap-2">
          <Skeleton className="size-7 rounded-full" />
          <Skeleton className="h-4 w-24" />
        </div>
      </TableCell>
      <TableCell>
        <Skeleton className="h-5 w-20 rounded-full" />
      </TableCell>
      <TableCell className="hidden sm:table-cell">
        <Skeleton className="h-4 w-16" />
      </TableCell>
      <TableCell className="hidden lg:table-cell">
        <Skeleton className="h-4 w-20" />
      </TableCell>
    </TableRow>
  )
}
