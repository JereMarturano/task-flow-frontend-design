"use client"

import {
  ListChecks,
  Circle,
  Timer,
  CheckCircle2,
  ArrowUpRight,
  Plus,
  TrendingUp,
} from "lucide-react"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Progress } from "@/components/ui/progress"
import { StatusBadge } from "@/components/status-badge"
import { UserCell } from "@/components/user-cell"
import { useTasks } from "@/components/task-store"
import { useSimulatedLoading } from "@/hooks/use-simulated-loading"
import { formatRelative, priorityMeta } from "@/lib/data"
import type { View } from "@/components/app-sidebar"
import { cn } from "@/lib/utils"

export function DashboardView({
  onViewChange,
  onOpenTask,
  onCreate,
}: {
  onViewChange: (v: View) => void
  onOpenTask: (id: string) => void
  onCreate: () => void
}) {
  const { tasks } = useTasks()
  const loading = useSimulatedLoading()

  const total = tasks.length
  const todo = tasks.filter((t) => t.status === "ToDo").length
  const inProgress = tasks.filter((t) => t.status === "InProgress").length
  const done = tasks.filter((t) => t.status === "Done").length
  const completion = total ? Math.round((done / total) * 100) : 0

  const kpis = [
    {
      label: "Total tasks",
      value: total,
      icon: ListChecks,
      tint: "bg-primary/10 text-primary",
      delta: "+12%",
    },
    {
      label: "Pending",
      value: todo,
      icon: Circle,
      tint: "bg-muted text-muted-foreground",
      delta: "+3",
    },
    {
      label: "In progress",
      value: inProgress,
      icon: Timer,
      tint: "bg-sky-500/10 text-sky-600 dark:text-sky-400",
      delta: "+5",
    },
    {
      label: "Completed",
      value: done,
      icon: CheckCircle2,
      tint: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
      delta: "+8%",
    },
  ]

  const recent = [...tasks]
    .sort(
      (a, b) =>
        new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime(),
    )
    .slice(0, 5)

  return (
    <div className="mx-auto flex max-w-7xl flex-col gap-6 p-4 md:p-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-semibold tracking-tight text-balance">
            Welcome back, Ana
          </h2>
          <p className="text-sm text-muted-foreground">
            Here&apos;s what&apos;s happening across your team today.
          </p>
        </div>
        <Button onClick={onCreate} className="gap-2 max-sm:w-full">
          <Plus className="size-4" />
          New task
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {kpis.map((kpi) =>
          loading ? (
            <Card key={kpi.label}>
              <CardContent className="flex flex-col gap-3 p-5">
                <Skeleton className="size-10 rounded-lg" />
                <Skeleton className="h-7 w-16" />
                <Skeleton className="h-4 w-24" />
              </CardContent>
            </Card>
          ) : (
            <Card key={kpi.label} className="transition-shadow hover:shadow-sm">
              <CardContent className="flex flex-col gap-3 p-5">
                <div className="flex items-center justify-between">
                  <span
                    className={cn(
                      "flex size-10 items-center justify-center rounded-lg",
                      kpi.tint,
                    )}
                  >
                    <kpi.icon className="size-5" />
                  </span>
                  <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                    <TrendingUp className="size-3" />
                    {kpi.delta}
                  </span>
                </div>
                <div className="flex flex-col gap-0.5">
                  <span className="text-2xl font-semibold tabular-nums tracking-tight">
                    {kpi.value}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {kpi.label}
                  </span>
                </div>
              </CardContent>
            </Card>
          ),
        )}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between gap-2 space-y-0">
            <div className="space-y-1">
              <CardTitle className="text-base">Recent activity</CardTitle>
              <CardDescription>
                Latest updates across your workspace
              </CardDescription>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="gap-1"
              onClick={() => onViewChange("tasks")}
            >
              View all
              <ArrowUpRight className="size-4" />
            </Button>
          </CardHeader>
          <CardContent className="flex flex-col gap-1 px-2 pb-2">
            {loading
              ? Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center gap-3 px-3 py-2.5">
                    <Skeleton className="size-8 rounded-full" />
                    <div className="flex flex-1 flex-col gap-1.5">
                      <Skeleton className="h-4 w-2/3" />
                      <Skeleton className="h-3 w-1/3" />
                    </div>
                  </div>
                ))
              : recent.map((task) => (
                  <button
                    key={task.id}
                    onClick={() => onOpenTask(task.id)}
                    className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors hover:bg-accent/60"
                  >
                    <UserCell name={task.responsible} hideName />
                    <div className="flex min-w-0 flex-1 flex-col">
                      <span className="truncate text-sm font-medium">
                        {task.title}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {task.key} · updated {formatRelative(task.updatedAt)}
                      </span>
                    </div>
                    <StatusBadge
                      status={task.status}
                      className="max-sm:hidden"
                    />
                  </button>
                ))}
          </CardContent>
        </Card>

        <div className="flex flex-col gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Completion rate</CardTitle>
              <CardDescription>Across all tracked tasks</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              {loading ? (
                <Skeleton className="h-20 w-full" />
              ) : (
                <>
                  <div className="flex items-end justify-between">
                    <span className="text-3xl font-semibold tabular-nums">
                      {completion}%
                    </span>
                    <span className="text-sm text-muted-foreground">
                      {done}/{total} done
                    </span>
                  </div>
                  <Progress value={completion} />
                  <div className="grid grid-cols-3 gap-2 pt-1 text-center">
                    {[
                      { label: "To Do", value: todo },
                      { label: "Active", value: inProgress },
                      { label: "Done", value: done },
                    ].map((s) => (
                      <div
                        key={s.label}
                        className="rounded-lg border border-border bg-muted/40 py-2"
                      >
                        <div className="text-lg font-semibold tabular-nums">
                          {s.value}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {s.label}
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Up next</CardTitle>
              <CardDescription>High priority & pending</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-1 px-2 pb-2">
              {loading
                ? Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="mx-1 h-9" />
                  ))
                : tasks
                    .filter(
                      (t) =>
                        t.status !== "Done" &&
                        (t.priority === "High" || t.priority === "Urgent"),
                    )
                    .slice(0, 3)
                    .map((t) => (
                      <button
                        key={t.id}
                        onClick={() => onOpenTask(t.id)}
                        className="flex items-center gap-2 rounded-lg px-2 py-2 text-left transition-colors hover:bg-accent/60"
                      >
                        <span
                          className={cn(
                            "text-xs font-semibold",
                            priorityMeta[t.priority].className,
                          )}
                        >
                          {priorityMeta[t.priority].label}
                        </span>
                        <span className="truncate text-sm">{t.title}</span>
                      </button>
                    ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
