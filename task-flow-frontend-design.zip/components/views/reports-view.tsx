"use client"

import { useMemo } from "react"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  XAxis,
  YAxis,
} from "recharts"
import {
  Activity,
  CheckCircle2,
  Clock,
  TrendingUp,
} from "lucide-react"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import { Progress } from "@/components/ui/progress"
import { useTasks } from "@/components/task-store"
import { useSimulatedLoading } from "@/hooks/use-simulated-loading"
import { members, statusMeta, type Priority } from "@/lib/data"
import { cn } from "@/lib/utils"

const statusConfig = {
  ToDo: { label: "To Do", color: "var(--color-muted-foreground)" },
  InProgress: { label: "In Progress", color: "var(--color-primary)" },
  Done: { label: "Done", color: "var(--color-chart-2)" },
} satisfies ChartConfig

const workloadConfig = {
  active: { label: "Active", color: "var(--color-primary)" },
  done: { label: "Done", color: "var(--color-chart-2)" },
} satisfies ChartConfig

const velocityConfig = {
  completed: { label: "Completed", color: "var(--color-primary)" },
} satisfies ChartConfig

const priorityColors: Record<Priority, string> = {
  Urgent: "var(--color-chart-1)",
  High: "var(--color-chart-3)",
  Medium: "var(--color-chart-4)",
  Low: "var(--color-chart-5)",
}

export function ReportsView() {
  const { tasks } = useTasks()
  const loading = useSimulatedLoading(600)

  const total = tasks.length
  const done = tasks.filter((t) => t.status === "Done").length
  const inProgress = tasks.filter((t) => t.status === "InProgress").length
  const completion = total ? Math.round((done / total) * 100) : 0

  const statusData = useMemo(
    () =>
      (Object.keys(statusMeta) as (keyof typeof statusMeta)[]).map((key) => ({
        status: key,
        label: statusMeta[key].label,
        value: tasks.filter((t) => t.status === key).length,
        fill: statusConfig[key].color,
      })),
    [tasks],
  )

  const workloadData = useMemo(
    () =>
      members.map((m) => {
        const assigned = tasks.filter((t) => t.responsible === m.name)
        return {
          name: m.name.split(" ")[0],
          active: assigned.filter((t) => t.status !== "Done").length,
          done: assigned.filter((t) => t.status === "Done").length,
        }
      }),
    [tasks],
  )

  const priorityData = useMemo(
    () =>
      (["Urgent", "High", "Medium", "Low"] as Priority[]).map((p) => ({
        priority: p,
        value: tasks.filter((t) => t.priority === p).length,
        fill: priorityColors[p],
      })),
    [tasks],
  )

  // Synthetic velocity trend (weeks)
  const velocityData = [
    { week: "W1", completed: 4 },
    { week: "W2", completed: 6 },
    { week: "W3", completed: 5 },
    { week: "W4", completed: 8 },
    { week: "W5", completed: 7 },
    { week: "W6", completed: done },
  ]

  const kpis = [
    {
      label: "Completion rate",
      value: `${completion}%`,
      icon: CheckCircle2,
      tint: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
    },
    {
      label: "Active tasks",
      value: inProgress,
      icon: Activity,
      tint: "bg-primary/10 text-primary",
    },
    {
      label: "Avg. cycle time",
      value: "3.2d",
      icon: Clock,
      tint: "bg-sky-500/10 text-sky-600 dark:text-sky-400",
    },
    {
      label: "Throughput / wk",
      value: "6.5",
      icon: TrendingUp,
      tint: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
    },
  ]

  return (
    <div className="mx-auto flex max-w-7xl flex-col gap-6 p-4 md:p-6">
      <div>
        <h2 className="text-xl font-semibold tracking-tight text-balance">
          Reports & analytics
        </h2>
        <p className="text-sm text-muted-foreground">
          Track velocity, workload, and the health of your workspace.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {kpis.map((kpi) =>
          loading ? (
            <Card key={kpi.label}>
              <CardContent className="flex items-center gap-4 p-5">
                <Skeleton className="size-10 rounded-lg" />
                <div className="flex flex-col gap-2">
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card key={kpi.label}>
              <CardContent className="flex items-center gap-4 p-5">
                <span
                  className={cn(
                    "flex size-10 items-center justify-center rounded-lg",
                    kpi.tint,
                  )}
                >
                  <kpi.icon className="size-5" />
                </span>
                <div className="flex flex-col">
                  <span className="text-2xl font-semibold tabular-nums tracking-tight">
                    {kpi.value}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {kpi.label}
                  </span>
                </div>
              </CardContent>
            </Card>
          ),
        )}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Velocity trend</CardTitle>
            <CardDescription>Tasks completed over the last 6 weeks</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[240px] w-full" />
            ) : (
              <ChartContainer config={velocityConfig} className="h-[240px] w-full">
                <LineChart data={velocityData} margin={{ left: 4, right: 12, top: 8 }}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis
                    dataKey="week"
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                  />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    width={28}
                    allowDecimals={false}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    dataKey="completed"
                    type="monotone"
                    stroke="var(--color-completed)"
                    strokeWidth={2}
                    dot={{ r: 3 }}
                    activeDot={{ r: 5 }}
                  />
                </LineChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Status distribution</CardTitle>
            <CardDescription>Current task breakdown</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-4">
            {loading ? (
              <Skeleton className="size-[180px] rounded-full" />
            ) : (
              <>
                <ChartContainer
                  config={statusConfig}
                  className="mx-auto aspect-square h-[180px]"
                >
                  <PieChart>
                    <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                    <Pie
                      data={statusData}
                      dataKey="value"
                      nameKey="label"
                      innerRadius={48}
                      strokeWidth={2}
                    >
                      {statusData.map((entry) => (
                        <Cell key={entry.status} fill={entry.fill} />
                      ))}
                    </Pie>
                  </PieChart>
                </ChartContainer>
                <div className="flex w-full flex-col gap-2">
                  {statusData.map((s) => (
                    <div
                      key={s.status}
                      className="flex items-center justify-between text-sm"
                    >
                      <span className="flex items-center gap-2">
                        <span
                          className="size-2.5 rounded-full"
                          style={{ backgroundColor: s.fill }}
                          aria-hidden
                        />
                        {s.label}
                      </span>
                      <span className="font-medium tabular-nums">{s.value}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Team workload</CardTitle>
            <CardDescription>Active vs. completed tasks per member</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[260px] w-full" />
            ) : (
              <ChartContainer config={workloadConfig} className="h-[260px] w-full">
                <BarChart data={workloadData} margin={{ left: 4, right: 8, top: 8 }}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis
                    dataKey="name"
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                  />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    width={28}
                    allowDecimals={false}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar
                    dataKey="active"
                    stackId="a"
                    fill="var(--color-active)"
                    radius={[0, 0, 4, 4]}
                  />
                  <Bar
                    dataKey="done"
                    stackId="a"
                    fill="var(--color-done)"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">By priority</CardTitle>
            <CardDescription>Open and closed tasks</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            {loading
              ? Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-9 w-full" />
                ))
              : priorityData.map((p) => {
                  const pct = total ? Math.round((p.value / total) * 100) : 0
                  return (
                    <div key={p.priority} className="flex flex-col gap-1.5">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium">{p.priority}</span>
                        <span className="text-muted-foreground tabular-nums">
                          {p.value} · {pct}%
                        </span>
                      </div>
                      <Progress value={pct} />
                    </div>
                  )
                })}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
