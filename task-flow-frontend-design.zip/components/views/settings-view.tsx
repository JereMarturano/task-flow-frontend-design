"use client"

import { useState } from "react"
import { useTheme } from "next-themes"
import { Monitor, Moon, Sun } from "lucide-react"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { avatarColor, initials } from "@/lib/data"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

const themeOptions = [
  { value: "light", label: "Light", icon: Sun },
  { value: "dark", label: "Dark", icon: Moon },
  { value: "system", label: "System", icon: Monitor },
] as const

const notificationOptions = [
  {
    id: "assigned",
    label: "Task assignments",
    description: "When a task is assigned to you",
    default: true,
  },
  {
    id: "mentions",
    label: "Mentions",
    description: "When someone @mentions you in a comment",
    default: true,
  },
  {
    id: "status",
    label: "Status changes",
    description: "When a task you follow changes status",
    default: false,
  },
  {
    id: "digest",
    label: "Weekly digest",
    description: "A summary of your team's activity every Monday",
    default: true,
  },
]

export function SettingsView() {
  const { theme, setTheme } = useTheme()
  const currentUser = { name: "Ana Torres", email: "ana.torres@novatech.io", role: "Product Lead" }

  const [notifications, setNotifications] = useState<Record<string, boolean>>(
    () =>
      Object.fromEntries(
        notificationOptions.map((o) => [o.id, o.default]),
      ),
  )

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6 p-4 md:p-6">
      <div>
        <h2 className="text-xl font-semibold tracking-tight text-balance">
          Settings
        </h2>
        <p className="text-sm text-muted-foreground">
          Manage your profile, appearance, and notification preferences.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Profile</CardTitle>
          <CardDescription>Update your personal information.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-5">
          <div className="flex items-center gap-4">
            <Avatar className="size-16">
              <AvatarFallback
                className={cn("text-lg font-medium", avatarColor(currentUser.name))}
              >
                {initials(currentUser.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-2">
              <Button variant="outline" size="sm">
                Change avatar
              </Button>
              <p className="text-xs text-muted-foreground">
                JPG, PNG or GIF. Max 2MB.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-2">
              <Label htmlFor="name">Full name</Label>
              <Input id="name" defaultValue={currentUser.name} />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="role">Role</Label>
              <Input id="role" defaultValue={currentUser.role} />
            </div>
            <div className="flex flex-col gap-2 sm:col-span-2">
              <Label htmlFor="email">Email address</Label>
              <Input id="email" type="email" defaultValue={currentUser.email} />
            </div>
          </div>
          <div className="flex justify-end">
            <Button onClick={() => toast.success("Profile updated")}>
              Save changes
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Appearance</CardTitle>
          <CardDescription>
            Choose how TaskFlow looks on this device.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3">
            {themeOptions.map((opt) => {
              const active = theme === opt.value
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setTheme(opt.value)}
                  aria-pressed={active}
                  className={cn(
                    "flex flex-col items-center gap-2 rounded-lg border p-4 text-sm font-medium transition-colors",
                    active
                      ? "border-primary bg-primary/5 text-foreground"
                      : "border-border text-muted-foreground hover:bg-accent/60 hover:text-foreground",
                  )}
                >
                  <opt.icon className="size-5" />
                  {opt.label}
                </button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Notifications</CardTitle>
          <CardDescription>
            Decide what updates land in your inbox.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col">
          {notificationOptions.map((opt, i) => (
            <div key={opt.id}>
              {i > 0 && <Separator />}
              <div className="flex items-center justify-between gap-4 py-4">
                <div className="flex flex-col gap-0.5">
                  <Label htmlFor={`notif-${opt.id}`} className="font-medium">
                    {opt.label}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {opt.description}
                  </p>
                </div>
                <Switch
                  id={`notif-${opt.id}`}
                  checked={notifications[opt.id]}
                  onCheckedChange={(checked) =>
                    setNotifications((prev) => ({ ...prev, [opt.id]: checked }))
                  }
                />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-destructive/30">
        <CardHeader>
          <CardTitle className="text-base text-destructive">
            Danger zone
          </CardTitle>
          <CardDescription>
            Irreversible actions for your workspace.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-col gap-0.5">
            <span className="text-sm font-medium">Delete workspace</span>
            <span className="text-sm text-muted-foreground">
              Permanently remove NovaTech and all of its data.
            </span>
          </div>
          <Button
            variant="destructive"
            onClick={() => toast.error("This is a demo — deletion is disabled")}
          >
            Delete workspace
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
