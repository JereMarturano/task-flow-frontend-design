"use client"

import { useState } from "react"
import { Plus, GripVertical } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { UserCell } from "@/components/user-cell"
import { useTasks } from "@/components/task-store"
import {
  statusMeta,
  priorityMeta,
  type Task,
  type TaskStatus,
} from "@/lib/data"
import { useSimulatedLoading } from "@/hooks/use-simulated-loading"
import { cn } from "@/lib/utils"

const columns: TaskStatus[] = ["ToDo", "InProgress", "Done"]

export function KanbanView({
  onOpenTask,
  onCreate,
}: {
  onOpenTask: (id: string) => void
  onCreate: () => void
}) {
  const { tasks, updateStatus } = useTasks()
  const loading = useSimulatedLoading(500)
  const [draggingId, setDraggingId] = useState<string | null>(null)
  const [dragOver, setDragOver] = useState<TaskStatus | null>(null)

  const handleDrop = (status: TaskStatus) => {
    if (draggingId) updateStatus(draggingId, status)
    setDraggingId(null)
    setDragOver(null)
  }

  return (
    <div className="flex h-full flex-col gap-4 p-4 md:p-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Drag cards between columns to update their status.
        </p>
        <Button size="sm" onClick={onCreate}>
          <Plus data-icon="inline-start" />
          New Task
        </Button>
      </div>

      <div className="grid flex-1 grid-cols-1 gap-4 md:grid-cols-3">
        {columns.map((status) => {
          const columnTasks = tasks.filter((t) => t.status === status)
          const meta = statusMeta[status]
          return (
            <section
              key={status}
              onDragOver={(e) => {
                e.preventDefault()
                setDragOver(status)
              }}
              onDragLeave={(e) => {
                if (e.currentTarget === e.target) setDragOver(null)
              }}
              onDrop={() => handleDrop(status)}
              className={cn(
                "flex flex-col gap-3 rounded-xl border bg-muted/40 p-3 transition-colors",
                dragOver === status && "border-primary/60 bg-primary/5",
              )}
              aria-label={meta.label}
            >
              <header className="flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <span
                    className={cn("size-2 rounded-full", meta.dot)}
                    aria-hidden
                  />
                  <h3 className="text-sm font-semibold text-foreground">
                    {meta.label}
                  </h3>
                  <Badge variant="secondary" className="font-normal">
                    {columnTasks.length}
                  </Badge>
                </div>
              </header>

              <div className="flex flex-1 flex-col gap-2.5">
                {loading ? (
                  Array.from({ length: status === "ToDo" ? 3 : 2 }).map(
                    (_, i) => <CardSkeleton key={i} />,
                  )
                ) : columnTasks.length === 0 ? (
                  <div className="flex flex-1 items-center justify-center rounded-lg border border-dashed py-10 text-center text-sm text-muted-foreground">
                    No tasks
                  </div>
                ) : (
                  columnTasks.map((task) => (
                    <KanbanCard
                      key={task.id}
                      task={task}
                      dragging={draggingId === task.id}
                      onDragStart={() => setDraggingId(task.id)}
                      onDragEnd={() => {
                        setDraggingId(null)
                        setDragOver(null)
                      }}
                      onOpen={() => onOpenTask(task.id)}
                    />
                  ))
                )}
              </div>
            </section>
          )
        })}
      </div>
    </div>
  )
}

function KanbanCard({
  task,
  dragging,
  onDragStart,
  onDragEnd,
  onOpen,
}: {
  task: Task
  dragging: boolean
  onDragStart: () => void
  onDragEnd: () => void
  onOpen: () => void
}) {
  return (
    <article
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onClick={onOpen}
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter") onOpen()
      }}
      className={cn(
        "group cursor-pointer rounded-lg border bg-card p-3 shadow-sm transition-all hover:border-primary/40 hover:shadow-md",
        dragging && "opacity-50 ring-2 ring-primary",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <span className="font-mono text-xs text-muted-foreground">
          {task.key}
        </span>
        <GripVertical
          className="size-4 text-muted-foreground/40 transition-colors group-hover:text-muted-foreground"
          aria-hidden
        />
      </div>
      <h4 className="mt-1.5 text-sm font-medium leading-snug text-foreground">
        {task.title}
      </h4>
      {task.tags.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          {task.tags.map((tag) => (
            <Badge key={tag} variant="secondary" className="font-normal">
              {tag}
            </Badge>
          ))}
        </div>
      )}
      <div className="mt-3 flex items-center justify-between">
        <UserCell name={task.responsible} hideName />
        <span
          className={cn(
            "inline-flex items-center gap-1.5 text-xs font-medium",
            priorityMeta[task.priority].className,
          )}
        >
          <span className="size-1.5 rounded-full bg-current" aria-hidden />
          {priorityMeta[task.priority].label}
        </span>
      </div>
    </article>
  )
}

function CardSkeleton() {
  return (
    <div className="rounded-lg border bg-card p-3">
      <Skeleton className="h-3 w-14" />
      <Skeleton className="mt-2 h-4 w-full" />
      <Skeleton className="mt-1.5 h-4 w-2/3" />
      <div className="mt-3 flex items-center justify-between">
        <Skeleton className="size-7 rounded-full" />
        <Skeleton className="h-3 w-12" />
      </div>
    </div>
  )
}
