"use client"

import {
  CalendarPlus,
  Clock,
  MessageSquare,
  RefreshCw,
  UserPlus,
  CheckCircle2,
} from "lucide-react"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { StatusBadge } from "@/components/status-badge"
import { useTasks } from "@/components/task-store"
import {
  priorityMeta,
  avatarColor,
  initials,
  formatDate,
  formatRelative,
  type ActivityEntry,
  type TaskStatus,
} from "@/lib/data"
import { cn } from "@/lib/utils"

const activityIcon: Record<ActivityEntry["type"], typeof Clock> = {
  created: CalendarPlus,
  status: RefreshCw,
  assigned: UserPlus,
  comment: MessageSquare,
  updated: CheckCircle2,
}

export function TaskDetailDrawer({
  taskId,
  onClose,
}: {
  taskId: string | null
  onClose: () => void
}) {
  const { getTask, updateStatus } = useTasks()
  const task = taskId ? getTask(taskId) : undefined

  return (
    <Sheet open={!!taskId} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="w-full gap-0 overflow-y-auto p-0 sm:max-w-md">
        {task ? (
          <>
            <SheetHeader className="gap-2 border-b p-5">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-muted-foreground">
                  {task.key}
                </span>
                <StatusBadge status={task.status} />
              </div>
              <SheetTitle className="text-balance text-lg leading-snug">
                {task.title}
              </SheetTitle>
              <SheetDescription className="sr-only">
                Task details and activity for {task.key}
              </SheetDescription>
            </SheetHeader>

            <div className="flex flex-col gap-5 p-5">
              {task.description && (
                <div className="flex flex-col gap-1.5">
                  <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Description
                  </h3>
                  <p className="text-sm leading-relaxed text-foreground">
                    {task.description}
                  </p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <Detail label="Assignee">
                  <div className="flex items-center gap-2">
                    <Avatar className="size-6">
                      <AvatarFallback
                        className={cn("text-[10px]", avatarColor(task.responsible))}
                      >
                        {initials(task.responsible)}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium">
                      {task.responsible}
                    </span>
                  </div>
                </Detail>
                <Detail label="Priority">
                  <span
                    className={cn(
                      "inline-flex items-center gap-1.5 text-sm font-medium",
                      priorityMeta[task.priority].className,
                    )}
                  >
                    <span
                      className="size-1.5 rounded-full bg-current"
                      aria-hidden
                    />
                    {priorityMeta[task.priority].label}
                  </span>
                </Detail>
                <Detail label="Created">
                  <span className="text-sm">{formatDate(task.createdAt)}</span>
                </Detail>
                <Detail label="Updated">
                  <span className="text-sm">
                    {formatRelative(task.updatedAt)}
                  </span>
                </Detail>
              </div>

              <div className="flex flex-col gap-1.5">
                <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Update status
                </h3>
                <Select
                  value={task.status}
                  onValueChange={(v) => updateStatus(task.id, v as TaskStatus)}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ToDo">To Do</SelectItem>
                    <SelectItem value="InProgress">In Progress</SelectItem>
                    <SelectItem value="Done">Done</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {task.tags.length > 0 && (
                <div className="flex flex-col gap-1.5">
                  <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Tags
                  </h3>
                  <div className="flex flex-wrap gap-1.5">
                    {task.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="font-normal">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <Separator />

              <div className="flex flex-col gap-3">
                <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Activity
                </h3>
                <ol className="flex flex-col gap-4">
                  {[...task.activity].reverse().map((entry) => {
                    const Icon = activityIcon[entry.type]
                    return (
                      <li key={entry.id} className="flex gap-3">
                        <div className="flex size-7 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
                          <Icon className="size-3.5" />
                        </div>
                        <div className="flex flex-col gap-0.5">
                          <p className="text-sm leading-snug">
                            <span className="font-medium text-foreground">
                              {entry.actor}
                            </span>{" "}
                            <span className="text-muted-foreground">
                              {entry.message}
                            </span>
                          </p>
                          <span className="text-xs text-muted-foreground">
                            {formatRelative(entry.timestamp)}
                          </span>
                        </div>
                      </li>
                    )
                  })}
                </ol>
              </div>
            </div>
          </>
        ) : null}
      </SheetContent>
    </Sheet>
  )
}

function Detail({
  label,
  children,
}: {
  label: string
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {label}
      </h3>
      {children}
    </div>
  )
}
