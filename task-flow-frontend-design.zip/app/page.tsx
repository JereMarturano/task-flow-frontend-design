"use client"

import { useState } from "react"
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar"
import { AppSidebar, type View } from "@/components/app-sidebar"
import { AppHeader } from "@/components/app-header"
import { TaskProvider } from "@/components/task-store"
import { CreateTaskDialog } from "@/components/create-task-dialog"
import { TaskDetailDrawer } from "@/components/task-detail-drawer"
import { DashboardView } from "@/components/views/dashboard-view"
import { TasksView } from "@/components/views/tasks-view"
import { KanbanView } from "@/components/views/kanban-view"
import { TeamView } from "@/components/views/team-view"
import { ReportsView } from "@/components/views/reports-view"
import { SettingsView } from "@/components/views/settings-view"

const titles: Record<View, string> = {
  dashboard: "Dashboard",
  tasks: "Tasks",
  kanban: "Kanban Board",
  team: "Team",
  reports: "Reports",
  settings: "Settings",
}

export default function Page() {
  const [view, setView] = useState<View>("dashboard")
  const [createOpen, setCreateOpen] = useState(false)
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null)

  const openTask = (id: string) => setSelectedTaskId(id)

  return (
    <TaskProvider>
      <SidebarProvider>
        <AppSidebar
          view={view}
          onChange={setView}
          onCreate={() => setCreateOpen(true)}
        />
        <SidebarInset className="min-w-0">
          <AppHeader title={titles[view]} />
          <main className="flex-1 overflow-x-hidden">
            {view === "dashboard" && (
              <DashboardView
                onViewChange={setView}
                onOpenTask={openTask}
                onCreate={() => setCreateOpen(true)}
              />
            )}
            {view === "tasks" && (
              <TasksView
                onOpenTask={openTask}
                onCreate={() => setCreateOpen(true)}
              />
            )}
            {view === "kanban" && (
              <KanbanView
                onOpenTask={openTask}
                onCreate={() => setCreateOpen(true)}
              />
            )}
            {view === "team" && <TeamView />}
            {view === "reports" && <ReportsView />}
            {view === "settings" && <SettingsView />}
          </main>
        </SidebarInset>
      </SidebarProvider>

      <CreateTaskDialog open={createOpen} onOpenChange={setCreateOpen} />
      <TaskDetailDrawer
        taskId={selectedTaskId}
        onClose={() => setSelectedTaskId(null)}
      />
    </TaskProvider>
  )
}
