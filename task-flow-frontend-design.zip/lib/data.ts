export type TaskStatus = "ToDo" | "InProgress" | "Done"

export type Priority = "Low" | "Medium" | "High" | "Urgent"

export interface Member {
  id: string
  name: string
  email: string
  role: string
  avatar?: string
}

export interface ActivityEntry {
  id: string
  type: "created" | "status" | "assigned" | "comment" | "updated"
  actor: string
  message: string
  timestamp: string
}

export interface Task {
  id: string
  key: string
  title: string
  description?: string
  responsible: string
  status: TaskStatus
  priority: Priority
  tags: string[]
  createdAt: string
  updatedAt: string
  activity: ActivityEntry[]
}

export const members: Member[] = [
  { id: "u1", name: "Ana Torres", email: "ana.torres@novatech.io", role: "Product Lead" },
  { id: "u2", name: "Marco Silva", email: "marco.silva@novatech.io", role: "Senior Engineer" },
  { id: "u3", name: "Lena Park", email: "lena.park@novatech.io", role: "UX Designer" },
  { id: "u4", name: "Diego Ramos", email: "diego.ramos@novatech.io", role: "Backend Engineer" },
  { id: "u5", name: "Sofia Nguyen", email: "sofia.nguyen@novatech.io", role: "QA Engineer" },
  { id: "u6", name: "Tom Becker", email: "tom.becker@novatech.io", role: "DevOps" },
]

export const statusMeta: Record<
  TaskStatus,
  { label: string; dot: string; badge: string }
> = {
  ToDo: {
    label: "To Do",
    dot: "bg-muted-foreground",
    badge: "bg-muted text-muted-foreground",
  },
  InProgress: {
    label: "In Progress",
    dot: "bg-primary",
    badge: "bg-primary/10 text-primary",
  },
  Done: {
    label: "Done",
    dot: "bg-emerald-500",
    badge: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
  },
}

export const priorityMeta: Record<Priority, { label: string; className: string }> = {
  Low: { label: "Low", className: "text-muted-foreground" },
  Medium: { label: "Medium", className: "text-sky-600 dark:text-sky-400" },
  High: { label: "High", className: "text-amber-600 dark:text-amber-400" },
  Urgent: { label: "Urgent", className: "text-red-600 dark:text-red-400" },
}

export const tasks: Task[] = [
  {
    id: "1",
    key: "NOVA-101",
    title: "Design onboarding flow for new workspaces",
    description:
      "Create a guided multi-step onboarding experience covering workspace setup, team invites, and the first board. Include empty states and progress indicators.",
    responsible: "Lena Park",
    status: "InProgress",
    priority: "High",
    tags: ["design", "onboarding"],
    createdAt: "2025-05-28T09:12:00Z",
    updatedAt: "2025-06-04T14:30:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Ana Torres", message: "created this task", timestamp: "2025-05-28T09:12:00Z" },
      { id: "a2", type: "assigned", actor: "Ana Torres", message: "assigned Lena Park", timestamp: "2025-05-28T09:13:00Z" },
      { id: "a3", type: "status", actor: "Lena Park", message: "moved to In Progress", timestamp: "2025-06-01T10:05:00Z" },
      { id: "a4", type: "comment", actor: "Lena Park", message: "First wireframes ready for review", timestamp: "2025-06-04T14:30:00Z" },
    ],
  },
  {
    id: "2",
    key: "NOVA-102",
    title: "Implement JWT refresh token rotation",
    description:
      "Add secure refresh token rotation with reuse detection on the auth service. Update the ASP.NET middleware and document the new flow.",
    responsible: "Diego Ramos",
    status: "ToDo",
    priority: "Urgent",
    tags: ["backend", "security"],
    createdAt: "2025-06-02T08:00:00Z",
    updatedAt: "2025-06-02T08:00:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Marco Silva", message: "created this task", timestamp: "2025-06-02T08:00:00Z" },
      { id: "a2", type: "assigned", actor: "Marco Silva", message: "assigned Diego Ramos", timestamp: "2025-06-02T08:01:00Z" },
    ],
  },
  {
    id: "3",
    key: "NOVA-103",
    title: "Migrate analytics tables to PostgreSQL 16",
    description:
      "Plan and execute the migration of the analytics schema to PostgreSQL 16, including partitioning strategy and zero-downtime cutover.",
    responsible: "Tom Becker",
    status: "InProgress",
    priority: "High",
    tags: ["infra", "database"],
    createdAt: "2025-05-20T11:45:00Z",
    updatedAt: "2025-06-03T16:20:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Tom Becker", message: "created this task", timestamp: "2025-05-20T11:45:00Z" },
      { id: "a2", type: "status", actor: "Tom Becker", message: "moved to In Progress", timestamp: "2025-05-29T09:00:00Z" },
    ],
  },
  {
    id: "4",
    key: "NOVA-104",
    title: "Build Kanban drag-and-drop interactions",
    description:
      "Implement smooth drag-and-drop on the Kanban board with keyboard accessibility and optimistic UI updates.",
    responsible: "Marco Silva",
    status: "Done",
    priority: "Medium",
    tags: ["frontend", "kanban"],
    createdAt: "2025-05-10T13:00:00Z",
    updatedAt: "2025-05-30T17:00:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Ana Torres", message: "created this task", timestamp: "2025-05-10T13:00:00Z" },
      { id: "a2", type: "status", actor: "Marco Silva", message: "moved to Done", timestamp: "2025-05-30T17:00:00Z" },
    ],
  },
  {
    id: "5",
    key: "NOVA-105",
    title: "Write end-to-end tests for task lifecycle",
    description:
      "Cover create, assign, transition, and delete flows with Playwright. Add CI gating on the main branch.",
    responsible: "Sofia Nguyen",
    status: "ToDo",
    priority: "Medium",
    tags: ["qa", "testing"],
    createdAt: "2025-06-03T10:30:00Z",
    updatedAt: "2025-06-03T10:30:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Sofia Nguyen", message: "created this task", timestamp: "2025-06-03T10:30:00Z" },
    ],
  },
  {
    id: "6",
    key: "NOVA-106",
    title: "Refine global search with fuzzy matching",
    description:
      "Improve the global search to support fuzzy matching across task titles, keys, and assignees with highlighted results.",
    responsible: "Ana Torres",
    status: "InProgress",
    priority: "Low",
    tags: ["frontend", "search"],
    createdAt: "2025-05-25T15:10:00Z",
    updatedAt: "2025-06-02T12:00:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Ana Torres", message: "created this task", timestamp: "2025-05-25T15:10:00Z" },
      { id: "a2", type: "status", actor: "Ana Torres", message: "moved to In Progress", timestamp: "2025-05-31T09:30:00Z" },
    ],
  },
  {
    id: "7",
    key: "NOVA-107",
    title: "Set up reporting dashboard widgets",
    description:
      "Create configurable widgets for velocity, throughput, and cycle time on the reports page.",
    responsible: "Lena Park",
    status: "Done",
    priority: "Medium",
    tags: ["frontend", "reports"],
    createdAt: "2025-04-30T09:00:00Z",
    updatedAt: "2025-05-22T18:45:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Ana Torres", message: "created this task", timestamp: "2025-04-30T09:00:00Z" },
      { id: "a2", type: "status", actor: "Lena Park", message: "moved to Done", timestamp: "2025-05-22T18:45:00Z" },
    ],
  },
  {
    id: "8",
    key: "NOVA-108",
    title: "Add rate limiting to public API endpoints",
    description:
      "Introduce token-bucket rate limiting on public endpoints with per-key quotas and informative headers.",
    responsible: "Diego Ramos",
    status: "ToDo",
    priority: "High",
    tags: ["backend", "api"],
    createdAt: "2025-06-04T07:20:00Z",
    updatedAt: "2025-06-04T07:20:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Diego Ramos", message: "created this task", timestamp: "2025-06-04T07:20:00Z" },
    ],
  },
  {
    id: "9",
    key: "NOVA-109",
    title: "Improve mobile responsiveness of board view",
    description:
      "Optimize the board layout for tablet and mobile breakpoints with horizontal scroll and compact cards.",
    responsible: "Marco Silva",
    status: "InProgress",
    priority: "Medium",
    tags: ["frontend", "responsive"],
    createdAt: "2025-05-27T14:00:00Z",
    updatedAt: "2025-06-05T08:15:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Ana Torres", message: "created this task", timestamp: "2025-05-27T14:00:00Z" },
      { id: "a2", type: "status", actor: "Marco Silva", message: "moved to In Progress", timestamp: "2025-06-02T11:00:00Z" },
    ],
  },
  {
    id: "10",
    key: "NOVA-110",
    title: "Document deployment pipeline runbook",
    description:
      "Write a clear runbook for the staging and production deployment pipelines including rollback procedures.",
    responsible: "Tom Becker",
    status: "Done",
    priority: "Low",
    tags: ["infra", "docs"],
    createdAt: "2025-04-18T10:00:00Z",
    updatedAt: "2025-05-15T13:30:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Tom Becker", message: "created this task", timestamp: "2025-04-18T10:00:00Z" },
      { id: "a2", type: "status", actor: "Tom Becker", message: "moved to Done", timestamp: "2025-05-15T13:30:00Z" },
    ],
  },
  {
    id: "11",
    key: "NOVA-111",
    title: "Create reusable empty-state component",
    description:
      "Build a flexible empty-state component used across boards, tables, and search results.",
    responsible: "Lena Park",
    status: "ToDo",
    priority: "Low",
    tags: ["frontend", "design-system"],
    createdAt: "2025-06-05T09:40:00Z",
    updatedAt: "2025-06-05T09:40:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Lena Park", message: "created this task", timestamp: "2025-06-05T09:40:00Z" },
    ],
  },
  {
    id: "12",
    key: "NOVA-112",
    title: "Audit accessibility across core flows",
    description:
      "Run an accessibility audit on the main workspace flows and file issues for contrast, focus order, and ARIA gaps.",
    responsible: "Sofia Nguyen",
    status: "InProgress",
    priority: "High",
    tags: ["qa", "a11y"],
    createdAt: "2025-05-22T16:30:00Z",
    updatedAt: "2025-06-04T10:10:00Z",
    activity: [
      { id: "a1", type: "created", actor: "Ana Torres", message: "created this task", timestamp: "2025-05-22T16:30:00Z" },
      { id: "a2", type: "status", actor: "Sofia Nguyen", message: "moved to In Progress", timestamp: "2025-05-30T09:00:00Z" },
    ],
  },
]

export function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase()
}

export function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  })
}

export function formatRelative(iso: string) {
  const date = new Date(iso)
  const now = new Date()
  const diff = Math.floor((now.getTime() - date.getTime()) / 1000)
  const day = 86400
  if (diff < 3600) return `${Math.max(1, Math.floor(diff / 60))}m ago`
  if (diff < day) return `${Math.floor(diff / 3600)}h ago`
  if (diff < day * 30) return `${Math.floor(diff / day)}d ago`
  return formatDate(iso)
}

// Deterministic accent color per member for avatars
export function avatarColor(name: string) {
  const palette = [
    "bg-blue-500/15 text-blue-600 dark:text-blue-300",
    "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300",
    "bg-amber-500/15 text-amber-600 dark:text-amber-300",
    "bg-rose-500/15 text-rose-600 dark:text-rose-300",
    "bg-cyan-500/15 text-cyan-600 dark:text-cyan-300",
    "bg-indigo-500/15 text-indigo-600 dark:text-indigo-300",
  ]
  let hash = 0
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash)
  return palette[Math.abs(hash) % palette.length]
}
